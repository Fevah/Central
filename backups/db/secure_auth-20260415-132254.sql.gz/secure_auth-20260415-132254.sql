--
-- PostgreSQL database dump
--

\restrict wwVVgyAleo4MOveXJfSlN1QlX7MSsRVRP3CJ4LKTdK9kL5FKhJNe9gBApJGGyEu

-- Dumped from database version 18.3
-- Dumped by pg_dump version 18.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA public;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: audit_action; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.audit_action AS ENUM (
    'login_success',
    'login_failure',
    'logout',
    'password_change',
    'password_reset_request',
    'password_reset_complete',
    'mfa_enable',
    'mfa_disable',
    'mfa_verify_success',
    'mfa_verify_failure',
    'user_create',
    'user_update',
    'user_delete',
    'role_assign',
    'role_revoke',
    'session_create',
    'session_revoke',
    'token_refresh',
    'token_revoke',
    'tenant_create',
    'tenant_update',
    'tenant_suspend',
    'tenant_delete',
    'permission_grant',
    'permission_revoke',
    'api_key_create',
    'api_key_revoke',
    'sso_link',
    'sso_unlink'
);


--
-- Name: TYPE audit_action; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TYPE public.audit_action IS 'Auditable actions for compliance logging';


--
-- Name: mfa_method; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.mfa_method AS ENUM (
    'none',
    'totp',
    'webauthn',
    'sms',
    'email'
);


--
-- Name: TYPE mfa_method; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TYPE public.mfa_method IS 'Available multi-factor authentication methods';


--
-- Name: oauth_provider; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.oauth_provider AS ENUM (
    'local',
    'google',
    'microsoft',
    'github',
    'okta',
    'saml',
    'oidc_custom'
);


--
-- Name: TYPE oauth_provider; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TYPE public.oauth_provider IS 'Supported OAuth/SSO providers';


--
-- Name: session_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.session_status AS ENUM (
    'active',
    'expired',
    'revoked',
    'logged_out'
);


--
-- Name: TYPE session_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TYPE public.session_status IS 'Session lifecycle status';


--
-- Name: tenant_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.tenant_status AS ENUM (
    'pending_approval',
    'active',
    'suspended',
    'deactivated',
    'pending_deletion'
);


--
-- Name: TYPE tenant_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TYPE public.tenant_status IS 'Status lifecycle for tenants';


--
-- Name: tenant_tier; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.tenant_tier AS ENUM (
    'free',
    'starter',
    'professional',
    'enterprise',
    'custom'
);


--
-- Name: TYPE tenant_tier; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TYPE public.tenant_tier IS 'Subscription tier levels with different feature sets';


--
-- Name: user_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.user_status AS ENUM (
    'pending_verification',
    'active',
    'locked',
    'suspended',
    'deactivated'
);


--
-- Name: TYPE user_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TYPE public.user_status IS 'User account status lifecycle';


--
-- Name: calculate_audit_checksum(text, uuid, uuid, uuid, jsonb, timestamp with time zone); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.calculate_audit_checksum(p_action text, p_actor_id uuid, p_target_id uuid, p_tenant_id uuid, p_event_data jsonb, p_created_at timestamp with time zone) RETURNS character varying
    LANGUAGE plpgsql IMMUTABLE
    AS $$
BEGIN
    RETURN encode(digest(
        COALESCE(p_action, '') || COALESCE(p_actor_id::TEXT, '') || 
        COALESCE(p_target_id::TEXT, '') || COALESCE(p_tenant_id::TEXT, '') || 
        COALESCE(p_event_data::TEXT, '') || COALESCE(p_created_at::TEXT, ''),
        'sha256'), 'hex');
END;
$$;


--
-- Name: get_current_tenant_id(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_current_tenant_id() RETURNS uuid
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    AS $$
DECLARE
    v_tenant_id TEXT;
BEGIN
    v_tenant_id := current_setting('app.tenant_id', true);
    IF v_tenant_id IS NULL OR v_tenant_id = '' THEN
        RETURN NULL;
    END IF;
    RETURN v_tenant_id::UUID;
EXCEPTION WHEN OTHERS THEN
    RETURN NULL;
END;
$$;


--
-- Name: FUNCTION get_current_tenant_id(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.get_current_tenant_id() IS 'Returns the current tenant ID from session context';


--
-- Name: get_current_user_id(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_current_user_id() RETURNS uuid
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    AS $$
DECLARE
    v_user_id TEXT;
BEGIN
    v_user_id := current_setting('app.user_id', true);
    IF v_user_id IS NULL OR v_user_id = '' THEN
        RETURN NULL;
    END IF;
    RETURN v_user_id::UUID;
EXCEPTION WHEN OTHERS THEN
    RETURN NULL;
END;
$$;


--
-- Name: is_device_trusted(uuid, character varying); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.is_device_trusted(p_user_id uuid, p_device_fingerprint character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM trusted_devices
        WHERE user_id = p_user_id
        AND device_fingerprint = p_device_fingerprint
        AND NOT is_revoked
        AND (trust_expires_at IS NULL OR trust_expires_at > NOW())
    );
END;
$$;


--
-- Name: is_super_admin(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.is_super_admin() RETURNS boolean
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    AS $$
DECLARE
    v_is_super TEXT;
BEGIN
    v_is_super := current_setting('app.is_super_admin', true);
    RETURN COALESCE(v_is_super = 'true', false);
EXCEPTION WHEN OTHERS THEN
    RETURN false;
END;
$$;


--
-- Name: FUNCTION is_super_admin(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.is_super_admin() IS 'Returns true if current session has super admin privileges';


--
-- Name: log_audit_event(public.audit_action, character varying, uuid, character varying, character varying, character varying, uuid, character varying, jsonb, boolean, text, numeric, jsonb, uuid, uuid, inet, character varying, character varying, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.log_audit_event(p_action public.audit_action, p_action_category character varying, p_actor_id uuid DEFAULT NULL::uuid, p_actor_email character varying DEFAULT NULL::character varying, p_actor_type character varying DEFAULT 'user'::character varying, p_target_type character varying DEFAULT NULL::character varying, p_target_id uuid DEFAULT NULL::uuid, p_target_email character varying DEFAULT NULL::character varying, p_event_data jsonb DEFAULT '{}'::jsonb, p_success boolean DEFAULT true, p_failure_reason text DEFAULT NULL::text, p_risk_score numeric DEFAULT NULL::numeric, p_risk_indicators jsonb DEFAULT NULL::jsonb, p_request_id uuid DEFAULT NULL::uuid, p_session_id uuid DEFAULT NULL::uuid, p_ip_address inet DEFAULT NULL::inet, p_ip_country character varying DEFAULT NULL::character varying, p_ip_city character varying DEFAULT NULL::character varying, p_user_agent text DEFAULT NULL::text) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    v_tenant_id UUID; v_checksum VARCHAR(64); v_external_id UUID; v_created_at TIMESTAMPTZ;
BEGIN
    v_tenant_id := get_current_tenant_id();
    v_created_at := NOW();
    v_checksum := calculate_audit_checksum(p_action::TEXT, p_actor_id, p_target_id, v_tenant_id, p_event_data, v_created_at);
    
    INSERT INTO audit_logs (action, action_category, actor_id, actor_email, actor_type,
        target_type, target_id, target_email, tenant_id, request_id, session_id,
        ip_address, ip_country, ip_city, user_agent, event_data, success, failure_reason,
        risk_score, risk_indicators, created_at, checksum)
    VALUES (p_action, p_action_category, p_actor_id, p_actor_email, p_actor_type,
        p_target_type, p_target_id, p_target_email, v_tenant_id, p_request_id, p_session_id,
        p_ip_address, p_ip_country, p_ip_city, p_user_agent, p_event_data, p_success, p_failure_reason,
        p_risk_score, p_risk_indicators, v_created_at, v_checksum)
    RETURNING external_id INTO v_external_id;
    
    RETURN v_external_id;
END;
$$;


--
-- Name: prevent_audit_modification(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.prevent_audit_modification() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    RAISE EXCEPTION 'Audit logs are immutable and cannot be modified or deleted';
END;
$$;


--
-- Name: refresh_dashboard_stats(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.refresh_dashboard_stats() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    REFRESH MATERIALIZED VIEW CONCURRENTLY mv_tenant_user_stats;
    REFRESH MATERIALIZED VIEW CONCURRENTLY mv_tenant_session_stats;
    REFRESH MATERIALIZED VIEW CONCURRENTLY mv_tenant_security_stats;
END;
$$;


--
-- Name: register_trusted_device(uuid, uuid, character varying, character varying, character varying, character varying, character varying, inet, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.register_trusted_device(p_user_id uuid, p_tenant_id uuid, p_device_fingerprint character varying, p_device_name character varying DEFAULT 'Unknown Device'::character varying, p_device_type character varying DEFAULT NULL::character varying, p_browser character varying DEFAULT NULL::character varying, p_os character varying DEFAULT NULL::character varying, p_ip_address inet DEFAULT NULL::inet, p_trust_days integer DEFAULT 30) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_id UUID;
    v_expires_at TIMESTAMP WITH TIME ZONE;
BEGIN
    v_expires_at := NOW() + (p_trust_days || ' days')::INTERVAL;
    
    INSERT INTO trusted_devices (
        user_id, tenant_id, device_fingerprint, device_name,
        device_type, browser, os, ip_address,
        trust_expires_at, last_used_at
    ) VALUES (
        p_user_id, p_tenant_id, p_device_fingerprint, p_device_name,
        p_device_type, p_browser, p_os, p_ip_address,
        v_expires_at, NOW()
    )
    ON CONFLICT (user_id, device_fingerprint) DO UPDATE SET
        device_name = COALESCE(EXCLUDED.device_name, trusted_devices.device_name),
        device_type = COALESCE(EXCLUDED.device_type, trusted_devices.device_type),
        browser = COALESCE(EXCLUDED.browser, trusted_devices.browser),
        os = COALESCE(EXCLUDED.os, trusted_devices.os),
        ip_address = COALESCE(EXCLUDED.ip_address, trusted_devices.ip_address),
        trust_expires_at = v_expires_at,
        last_used_at = NOW(),
        usage_count = trusted_devices.usage_count + 1,
        is_revoked = false,
        revoked_at = NULL,
        revoked_reason = NULL
    RETURNING id INTO v_id;
    
    RETURN v_id;
END;
$$;


--
-- Name: set_super_admin_context(boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_super_admin_context(p_is_super boolean) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    PERFORM set_config('app.is_super_admin', p_is_super::TEXT, false);
END;
$$;


--
-- Name: set_tenant_context(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_tenant_context(p_tenant_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    PERFORM set_config('app.tenant_id', p_tenant_id::TEXT, false);
END;
$$;


--
-- Name: FUNCTION set_tenant_context(p_tenant_id uuid); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.set_tenant_context(p_tenant_id uuid) IS 'Sets the tenant context for RLS. Must be called at connection start.';


--
-- Name: set_user_context(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_user_context(p_user_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    PERFORM set_config('app.user_id', p_user_id::TEXT, false);
END;
$$;


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


--
-- Name: validate_api_key(character varying); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.validate_api_key(p_key_hash character varying) RETURNS TABLE(api_key_id uuid, user_id uuid, tenant_id uuid, scopes text[], rate_limit_per_minute integer, is_valid boolean, error_message text)
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_key RECORD;
BEGIN
    SELECT * INTO v_key
    FROM api_keys
    WHERE key_hash = p_key_hash;
    
    IF NOT FOUND THEN
        RETURN QUERY SELECT 
            NULL::UUID, NULL::UUID, NULL::UUID, 
            NULL::TEXT[], NULL::INTEGER, 
            false, 'Invalid API key'::TEXT;
        RETURN;
    END IF;
    
    IF NOT v_key.is_active THEN
        RETURN QUERY SELECT 
            v_key.id, v_key.user_id, v_key.tenant_id,
            v_key.scopes, v_key.rate_limit_per_minute,
            false, 'API key is revoked'::TEXT;
        RETURN;
    END IF;
    
    IF v_key.expires_at IS NOT NULL AND v_key.expires_at < NOW() THEN
        RETURN QUERY SELECT 
            v_key.id, v_key.user_id, v_key.tenant_id,
            v_key.scopes, v_key.rate_limit_per_minute,
            false, 'API key has expired'::TEXT;
        RETURN;
    END IF;
    
    -- Update usage
    UPDATE api_keys 
    SET last_used_at = NOW(), usage_count = usage_count + 1
    WHERE id = v_key.id;
    
    RETURN QUERY SELECT 
        v_key.id, v_key.user_id, v_key.tenant_id,
        v_key.scopes, v_key.rate_limit_per_minute,
        true, NULL::TEXT;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: api_key_usage_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.api_key_usage_log (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    api_key_id uuid NOT NULL,
    endpoint character varying(255),
    method character varying(10),
    status_code integer,
    response_time_ms integer,
    ip_address inet,
    user_agent text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE api_key_usage_log; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.api_key_usage_log IS 'Usage log for API key analytics';


--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.api_keys (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    key_prefix character varying(10) NOT NULL,
    key_hash character varying(64) NOT NULL,
    permissions jsonb DEFAULT '[]'::jsonb NOT NULL,
    rate_limit_per_minute integer DEFAULT 60 NOT NULL,
    allowed_ips inet[],
    allowed_origins text[],
    last_used_at timestamp with time zone,
    last_used_ip inet,
    usage_count bigint DEFAULT 0 NOT NULL,
    expires_at timestamp with time zone,
    is_revoked boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    revoked_by uuid,
    revoked_reason character varying(255)
);


--
-- Name: TABLE api_keys; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.api_keys IS 'API keys for programmatic access to the platform';


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id bigint NOT NULL,
    external_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    action public.audit_action NOT NULL,
    action_category character varying(50) NOT NULL,
    actor_id uuid,
    actor_email character varying(255),
    actor_type character varying(50) DEFAULT 'user'::character varying NOT NULL,
    target_type character varying(100),
    target_id uuid,
    target_email character varying(255),
    tenant_id uuid,
    request_id uuid,
    session_id uuid,
    ip_address inet,
    ip_country character varying(2),
    ip_city character varying(100),
    user_agent text,
    event_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    success boolean DEFAULT true NOT NULL,
    failure_reason text,
    risk_score numeric(5,2),
    risk_indicators jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    checksum character varying(64)
)
WITH (autovacuum_vacuum_scale_factor='0.1', autovacuum_analyze_scale_factor='0.05', autovacuum_vacuum_cost_delay='10');
ALTER TABLE ONLY public.audit_logs ALTER COLUMN action SET STATISTICS 500;
ALTER TABLE ONLY public.audit_logs ALTER COLUMN tenant_id SET STATISTICS 1000;


--
-- Name: TABLE audit_logs; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.audit_logs IS 'Immutable audit log for all security-relevant events. Required for SOC2, HIPAA, GDPR compliance.';


--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: email_verification_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_verification_tokens (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    email character varying(255) NOT NULL,
    token_hash character varying(64) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    is_used boolean DEFAULT false NOT NULL,
    used_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE email_verification_tokens; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.email_verification_tokens IS 'Tokens for email verification during registration';


--
-- Name: group_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.group_members (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    group_id uuid NOT NULL,
    user_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    added_by uuid,
    added_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE group_members; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.group_members IS 'Membership join table between groups and users';


--
-- Name: groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.groups (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description text,
    group_type character varying(30) DEFAULT 'general'::character varying NOT NULL,
    is_public boolean DEFAULT false NOT NULL,
    auto_role_ids uuid[] DEFAULT '{}'::uuid[] NOT NULL,
    settings jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT groups_group_type_check CHECK (((group_type)::text = ANY ((ARRAY['general'::character varying, 'department'::character varying, 'permission_group'::character varying, 'distribution_list'::character varying])::text[])))
);


--
-- Name: TABLE groups; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.groups IS 'Groups for org-structure binding (departments, permission groups, distribution lists)';


--
-- Name: COLUMN groups.auto_role_ids; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.groups.auto_role_ids IS 'Roles automatically assigned to all members of this group';


--
-- Name: login_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.login_history (
    id bigint NOT NULL,
    user_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    success boolean NOT NULL,
    failure_reason character varying(100),
    session_id uuid,
    auth_method character varying(50),
    mfa_used boolean DEFAULT false NOT NULL,
    device_id character varying(255),
    device_type character varying(50),
    device_name character varying(255),
    ip_address inet NOT NULL,
    ip_country character varying(2),
    ip_city character varying(100),
    user_agent text,
    risk_score numeric(5,2),
    is_suspicious boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
)
WITH (autovacuum_vacuum_scale_factor='0.1', autovacuum_analyze_scale_factor='0.05', autovacuum_vacuum_cost_delay='10');


--
-- Name: TABLE login_history; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.login_history IS 'Login attempt history for security analytics and user session review.';


--
-- Name: login_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.login_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: login_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.login_history_id_seq OWNED BY public.login_history.id;


--
-- Name: mv_tenant_security_stats; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.mv_tenant_security_stats AS
 SELECT tenant_id,
    count(*) AS total_login_attempts_30d,
    count(*) FILTER (WHERE success) AS successful_logins_30d,
    count(*) FILTER (WHERE (NOT success)) AS failed_logins_30d,
    count(DISTINCT user_id) FILTER (WHERE (NOT success)) AS users_with_failures,
    count(*) FILTER (WHERE is_suspicious) AS suspicious_logins_30d
   FROM public.login_history
  WHERE (created_at > (now() - '30 days'::interval))
  GROUP BY tenant_id
  WITH NO DATA;


--
-- Name: MATERIALIZED VIEW mv_tenant_security_stats; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON MATERIALIZED VIEW public.mv_tenant_security_stats IS 'Security metrics for monitoring dashboards. Refresh every 5 minutes.';


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    session_token_hash character varying(64) NOT NULL,
    status public.session_status DEFAULT 'active'::public.session_status NOT NULL,
    device_id character varying(255),
    device_name character varying(255),
    device_type character varying(50),
    device_fingerprint character varying(64),
    user_agent text,
    client_version character varying(50),
    ip_address inet NOT NULL,
    ip_country character varying(2),
    ip_city character varying(100),
    last_activity_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    mfa_verified boolean DEFAULT false NOT NULL,
    mfa_verified_at timestamp with time zone,
    risk_score numeric(5,2) DEFAULT 0.00 NOT NULL,
    is_suspicious boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    revoked_by uuid,
    revoked_reason character varying(255)
)
WITH (autovacuum_vacuum_scale_factor='0.05', autovacuum_analyze_scale_factor='0.02', autovacuum_vacuum_cost_delay='5');
ALTER TABLE ONLY public.sessions ALTER COLUMN tenant_id SET STATISTICS 1000;
ALTER TABLE ONLY public.sessions ALTER COLUMN status SET STATISTICS 500;


--
-- Name: TABLE sessions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.sessions IS 'Active user sessions with device and network tracking';


--
-- Name: mv_tenant_session_stats; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.mv_tenant_session_stats AS
 SELECT tenant_id,
    count(*) AS total_sessions,
    count(*) FILTER (WHERE (status = 'active'::public.session_status)) AS active_sessions,
    count(*) FILTER (WHERE (created_at > (now() - '24:00:00'::interval))) AS sessions_24h,
    avg(EXTRACT(epoch FROM (last_activity_at - created_at))) AS avg_session_duration_seconds
   FROM public.sessions
  GROUP BY tenant_id
  WITH NO DATA;


--
-- Name: MATERIALIZED VIEW mv_tenant_session_stats; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON MATERIALIZED VIEW public.mv_tenant_session_stats IS 'Pre-aggregated session statistics. Refresh every 5 minutes.';


--
-- Name: tenants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenants (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(100) NOT NULL,
    domain character varying(255),
    tier public.tenant_tier DEFAULT 'free'::public.tenant_tier NOT NULL,
    status public.tenant_status DEFAULT 'pending_approval'::public.tenant_status NOT NULL,
    settings jsonb DEFAULT '{}'::jsonb NOT NULL,
    feature_flags jsonb DEFAULT '{}'::jsonb NOT NULL,
    rate_limits jsonb DEFAULT '{"max_users": 10, "storage_gb": 5, "api_requests_per_hour": 1000, "max_sessions_per_user": 5}'::jsonb NOT NULL,
    billing_email character varying(255),
    stripe_customer_id character varying(100),
    subscription_expires_at timestamp with time zone,
    sso_enabled boolean DEFAULT false NOT NULL,
    sso_config jsonb,
    data_region character varying(50) DEFAULT 'us-east-1'::character varying NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    activated_at timestamp with time zone,
    suspended_at timestamp with time zone,
    deleted_at timestamp with time zone,
    is_deleted boolean DEFAULT false NOT NULL,
    CONSTRAINT valid_domain CHECK (((domain IS NULL) OR ((domain)::text ~ '^[a-z0-9][a-z0-9.-]*\.[a-z]{2,}$'::text))),
    CONSTRAINT valid_slug CHECK (((slug)::text ~ '^[a-z0-9][a-z0-9-]*[a-z0-9]$'::text))
);


--
-- Name: TABLE tenants; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.tenants IS 'Root table for multi-tenant architecture. Each tenant represents an organization.';


--
-- Name: COLUMN tenants.slug; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tenants.slug IS 'URL-friendly unique identifier for tenant routing';


--
-- Name: COLUMN tenants.domain; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tenants.domain IS 'Custom domain for enterprise SSO and branding';


--
-- Name: COLUMN tenants.tier; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tenants.tier IS 'Subscription tier determining feature access and limits';


--
-- Name: COLUMN tenants.feature_flags; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tenants.feature_flags IS 'Per-tenant feature flag overrides for gradual rollouts';


--
-- Name: COLUMN tenants.rate_limits; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tenants.rate_limits IS 'Rate limiting configuration based on subscription tier';


--
-- Name: COLUMN tenants.sso_config; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tenants.sso_config IS 'SAML 2.0 or OIDC configuration for enterprise SSO';


--
-- Name: COLUMN tenants.data_region; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tenants.data_region IS 'AWS region for data residency compliance (GDPR)';


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    email character varying(255) NOT NULL,
    email_verified boolean DEFAULT false NOT NULL,
    email_verified_at timestamp with time zone,
    password_hash character varying(255),
    password_changed_at timestamp with time zone,
    password_expires_at timestamp with time zone,
    first_name_encrypted bytea,
    last_name_encrypted bytea,
    phone_encrypted bytea,
    display_name character varying(255),
    avatar_url character varying(500),
    locale character varying(10) DEFAULT 'en-US'::character varying NOT NULL,
    timezone character varying(50) DEFAULT 'UTC'::character varying NOT NULL,
    status public.user_status DEFAULT 'pending_verification'::public.user_status NOT NULL,
    mfa_enabled boolean DEFAULT false NOT NULL,
    mfa_method public.mfa_method DEFAULT 'none'::public.mfa_method NOT NULL,
    mfa_secret_encrypted bytea,
    mfa_backup_codes_encrypted bytea,
    mfa_recovery_email character varying(255),
    oauth_provider public.oauth_provider DEFAULT 'local'::public.oauth_provider NOT NULL,
    oauth_provider_id character varying(255),
    oauth_access_token_encrypted bytea,
    oauth_refresh_token_encrypted bytea,
    oauth_token_expires_at timestamp with time zone,
    failed_login_attempts integer DEFAULT 0 NOT NULL,
    locked_until timestamp with time zone,
    last_login_at timestamp with time zone,
    last_login_ip inet,
    last_password_reset_at timestamp with time zone,
    trusted_devices jsonb DEFAULT '[]'::jsonb NOT NULL,
    risk_score numeric(5,2) DEFAULT 0.00 NOT NULL,
    risk_factors jsonb DEFAULT '{}'::jsonb NOT NULL,
    terms_accepted_at timestamp with time zone,
    terms_version character varying(20),
    privacy_accepted_at timestamp with time zone,
    privacy_version character varying(20),
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deactivated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    is_deleted boolean DEFAULT false NOT NULL,
    CONSTRAINT mfa_secret_required_when_enabled CHECK (((NOT mfa_enabled) OR (mfa_method = 'none'::public.mfa_method) OR (mfa_secret_encrypted IS NOT NULL))),
    CONSTRAINT valid_email CHECK (((email)::text ~ '^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'::text))
);
ALTER TABLE ONLY public.users ALTER COLUMN tenant_id SET STATISTICS 1000;
ALTER TABLE ONLY public.users ALTER COLUMN email SET STATISTICS 1000;
ALTER TABLE ONLY public.users ALTER COLUMN status SET STATISTICS 500;


--
-- Name: TABLE users; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.users IS 'User accounts with encrypted PII fields for GDPR compliance';


--
-- Name: COLUMN users.password_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.users.password_hash IS 'Password hashed with Argon2id (256MB memory, 3 iterations, 4 parallelism)';


--
-- Name: COLUMN users.first_name_encrypted; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.users.first_name_encrypted IS 'First name encrypted with AES-256-GCM. Key managed in Key Vault.';


--
-- Name: COLUMN users.last_name_encrypted; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.users.last_name_encrypted IS 'Last name encrypted with AES-256-GCM. Key managed in Key Vault.';


--
-- Name: COLUMN users.phone_encrypted; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.users.phone_encrypted IS 'Phone number encrypted with AES-256-GCM. Key managed in Key Vault.';


--
-- Name: COLUMN users.mfa_secret_encrypted; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.users.mfa_secret_encrypted IS 'TOTP secret encrypted. Never expose in API responses.';


--
-- Name: COLUMN users.risk_score; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.users.risk_score IS 'Risk-based authentication score from 0.00 to 100.00';


--
-- Name: mv_tenant_user_stats; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.mv_tenant_user_stats AS
 SELECT t.id AS tenant_id,
    t.slug AS tenant_slug,
    t.tier AS tenant_tier,
    count(u.id) AS total_users,
    count(u.id) FILTER (WHERE (u.status = 'active'::public.user_status)) AS active_users,
    count(u.id) FILTER (WHERE u.mfa_enabled) AS mfa_enabled_users,
    count(u.id) FILTER (WHERE (u.last_login_at > (now() - '30 days'::interval))) AS monthly_active_users,
    count(u.id) FILTER (WHERE (u.last_login_at > (now() - '7 days'::interval))) AS weekly_active_users,
    max(u.created_at) AS last_user_created
   FROM (public.tenants t
     LEFT JOIN public.users u ON (((t.id = u.tenant_id) AND (NOT u.is_deleted))))
  WHERE (NOT t.is_deleted)
  GROUP BY t.id, t.slug, t.tier
  WITH NO DATA;


--
-- Name: MATERIALIZED VIEW mv_tenant_user_stats; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON MATERIALIZED VIEW public.mv_tenant_user_stats IS 'Pre-aggregated user statistics per tenant. Refresh every 5 minutes via cron.';


--
-- Name: oauth_linked_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_linked_accounts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    provider_id uuid NOT NULL,
    provider_user_id character varying(255) NOT NULL,
    provider_email character varying(255),
    provider_name character varying(255),
    provider_avatar_url text,
    access_token_encrypted bytea,
    refresh_token_encrypted bytea,
    token_expires_at timestamp with time zone,
    last_used_at timestamp with time zone,
    login_count integer DEFAULT 0 NOT NULL,
    linked_at timestamp with time zone DEFAULT now() NOT NULL,
    unlinked_at timestamp with time zone,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: TABLE oauth_linked_accounts; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.oauth_linked_accounts IS 'Links between users and their OAuth provider accounts';


--
-- Name: oauth_provider_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_provider_templates (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    provider_type character varying(50) NOT NULL,
    display_name character varying(100) NOT NULL,
    authorization_url text NOT NULL,
    token_url text NOT NULL,
    userinfo_url text,
    jwks_url text,
    default_scopes text[] NOT NULL,
    default_claim_mappings jsonb NOT NULL,
    setup_instructions text,
    documentation_url text,
    icon_url text,
    button_color character varying(20),
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: TABLE oauth_provider_templates; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.oauth_provider_templates IS 'Pre-configured templates for common OAuth providers';


--
-- Name: oauth_providers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_providers (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    provider_type character varying(50) NOT NULL,
    name character varying(100) NOT NULL,
    display_name character varying(100),
    client_id character varying(255) NOT NULL,
    client_secret_encrypted bytea NOT NULL,
    authorization_url text,
    token_url text,
    userinfo_url text,
    jwks_url text,
    scopes text[] DEFAULT ARRAY['openid'::text, 'profile'::text, 'email'::text],
    claim_mappings jsonb DEFAULT '{}'::jsonb,
    is_enabled boolean DEFAULT true NOT NULL,
    allow_signup boolean DEFAULT true NOT NULL,
    auto_link_by_email boolean DEFAULT false NOT NULL,
    require_email_verified boolean DEFAULT true NOT NULL,
    icon_url text,
    button_color character varying(20),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    metadata jsonb DEFAULT '{}'::jsonb
);


--
-- Name: TABLE oauth_providers; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.oauth_providers IS 'OAuth/OIDC provider configurations per tenant';


--
-- Name: oauth_states; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_states (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    state_token character varying(255) NOT NULL,
    nonce character varying(255),
    provider_id uuid NOT NULL,
    redirect_uri text NOT NULL,
    code_verifier character varying(128),
    client_ip inet,
    user_agent text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone DEFAULT (now() + '00:10:00'::interval) NOT NULL,
    used_at timestamp with time zone
);


--
-- Name: TABLE oauth_states; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.oauth_states IS 'Temporary OAuth state tokens for CSRF protection';


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.password_reset_tokens (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    token_hash character varying(64) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    is_used boolean DEFAULT false NOT NULL,
    used_at timestamp with time zone,
    used_ip inet,
    requested_ip inet NOT NULL,
    requested_user_agent text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE password_reset_tokens; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.password_reset_tokens IS 'Short-lived tokens for password reset flow';


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permissions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    code character varying(100) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    category character varying(100) NOT NULL,
    is_system boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE permissions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.permissions IS 'Fine-grained permissions for RBAC. System permissions are immutable.';


--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.refresh_tokens (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    session_id uuid NOT NULL,
    user_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    token_hash character varying(64) NOT NULL,
    token_family uuid NOT NULL,
    is_revoked boolean DEFAULT false NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    previous_token_id uuid,
    rotation_count integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    used_at timestamp with time zone,
    revoked_at timestamp with time zone,
    revoked_reason character varying(255)
)
WITH (autovacuum_vacuum_scale_factor='0.05', autovacuum_analyze_scale_factor='0.02', autovacuum_vacuum_cost_delay='5');


--
-- Name: TABLE refresh_tokens; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.refresh_tokens IS 'JWT refresh tokens with rotation support for security';


--
-- Name: COLUMN refresh_tokens.token_family; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.refresh_tokens.token_family IS 'Groups tokens in a rotation chain for detecting token reuse attacks';


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_permissions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    role_id uuid NOT NULL,
    permission_id uuid NOT NULL,
    conditions jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE role_permissions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.role_permissions IS 'Many-to-many mapping between roles and permissions';


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid,
    code character varying(100) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    priority integer DEFAULT 0 NOT NULL,
    is_system boolean DEFAULT false NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT system_roles_no_tenant CHECK (((NOT is_system) OR (tenant_id IS NULL)))
);


--
-- Name: TABLE roles; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.roles IS 'Roles that group permissions. System roles are shared across all tenants.';


--
-- Name: security_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.security_events (
    id bigint NOT NULL,
    event_type character varying(100) NOT NULL,
    severity character varying(20) NOT NULL,
    tenant_id uuid,
    user_id uuid,
    description text NOT NULL,
    event_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    detection_method character varying(100),
    confidence_score numeric(5,2),
    auto_action_taken character varying(100),
    requires_review boolean DEFAULT false NOT NULL,
    reviewed_at timestamp with time zone,
    reviewed_by uuid,
    review_notes text,
    ip_address inet,
    ip_country character varying(2),
    detected_at timestamp with time zone DEFAULT now() NOT NULL,
    resolved_at timestamp with time zone
);


--
-- Name: TABLE security_events; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.security_events IS 'Real-time security alerts for suspicious activities requiring investigation.';


--
-- Name: security_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.security_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: security_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.security_events_id_seq OWNED BY public.security_events.id;


--
-- Name: team_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.team_members (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    team_id uuid NOT NULL,
    user_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    role character varying(20) DEFAULT 'member'::character varying NOT NULL,
    invited_by uuid,
    joined_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT team_members_role_check CHECK (((role)::text = ANY ((ARRAY['owner'::character varying, 'admin'::character varying, 'member'::character varying, 'viewer'::character varying])::text[])))
);


--
-- Name: TABLE team_members; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.team_members IS 'Membership join table between teams and users with per-team role';


--
-- Name: teams; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.teams (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description text,
    parent_team_id uuid,
    is_public boolean DEFAULT false NOT NULL,
    settings jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: TABLE teams; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.teams IS 'Teams allow grouping users within a tenant; supports nested hierarchies via parent_team_id';


--
-- Name: trusted_devices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trusted_devices (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    device_fingerprint character varying(255) NOT NULL,
    device_name character varying(100) DEFAULT 'Unknown Device'::character varying NOT NULL,
    device_type character varying(50),
    browser character varying(100),
    os character varying(100),
    ip_address inet,
    location_country character varying(100),
    location_city character varying(100),
    trust_expires_at timestamp with time zone,
    trust_level character varying(20) DEFAULT 'standard'::character varying,
    last_used_at timestamp with time zone DEFAULT now() NOT NULL,
    usage_count integer DEFAULT 1 NOT NULL,
    is_revoked boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    revoked_reason character varying(255)
);


--
-- Name: TABLE trusted_devices; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.trusted_devices IS 'Devices trusted for MFA bypass';


--
-- Name: COLUMN trusted_devices.device_fingerprint; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.trusted_devices.device_fingerprint IS 'Unique device identifier hash';


--
-- Name: COLUMN trusted_devices.trust_level; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.trusted_devices.trust_level IS 'Level of trust: standard, high, temporary';


--
-- Name: user_invitations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_invitations (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    email character varying(255) NOT NULL,
    token_hash character varying(64) NOT NULL,
    role_ids uuid[] DEFAULT '{}'::uuid[] NOT NULL,
    invited_by uuid NOT NULL,
    message text,
    expires_at timestamp with time zone NOT NULL,
    accepted_at timestamp with time zone,
    accepted_by uuid,
    revoked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE user_invitations; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.user_invitations IS 'Pending user invitations with token-based acceptance';


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    role_id uuid NOT NULL,
    assigned_by uuid,
    expires_at timestamp with time zone,
    scope jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE user_roles; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.user_roles IS 'User role assignments with optional expiration and scope';


--
-- Name: webauthn_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webauthn_credentials (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    credential_id bytea NOT NULL,
    public_key bytea NOT NULL,
    name character varying(255) NOT NULL,
    aaguid uuid,
    sign_count bigint DEFAULT 0 NOT NULL,
    transports text[],
    attestation_type character varying(50),
    attestation_trust_path jsonb,
    last_used_at timestamp with time zone,
    usage_count integer DEFAULT 0 NOT NULL,
    is_revoked boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone
);


--
-- Name: TABLE webauthn_credentials; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.webauthn_credentials IS 'WebAuthn/FIDO2 credentials for passwordless authentication';


--
-- Name: COLUMN webauthn_credentials.credential_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.webauthn_credentials.credential_id IS 'Raw credential ID from authenticator';


--
-- Name: COLUMN webauthn_credentials.public_key; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.webauthn_credentials.public_key IS 'COSE-encoded public key';


--
-- Name: COLUMN webauthn_credentials.aaguid; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.webauthn_credentials.aaguid IS 'Authenticator Attestation GUID';


--
-- Name: COLUMN webauthn_credentials.sign_count; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.webauthn_credentials.sign_count IS 'Signature counter for replay prevention';


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: login_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.login_history ALTER COLUMN id SET DEFAULT nextval('public.login_history_id_seq'::regclass);


--
-- Name: security_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.security_events ALTER COLUMN id SET DEFAULT nextval('public.security_events_id_seq'::regclass);


--
-- Data for Name: api_key_usage_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.api_key_usage_log (id, api_key_id, endpoint, method, status_code, response_time_ms, ip_address, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.api_keys (id, user_id, tenant_id, name, key_prefix, key_hash, permissions, rate_limit_per_minute, allowed_ips, allowed_origins, last_used_at, last_used_ip, usage_count, expires_at, is_revoked, created_at, revoked_at, revoked_by, revoked_reason) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, external_id, action, action_category, actor_id, actor_email, actor_type, target_type, target_id, target_email, tenant_id, request_id, session_id, ip_address, ip_country, ip_city, user_agent, event_data, success, failure_reason, risk_score, risk_indicators, created_at, checksum) FROM stdin;
\.


--
-- Data for Name: email_verification_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_verification_tokens (id, user_id, tenant_id, email, token_hash, expires_at, is_used, used_at, created_at) FROM stdin;
8d096f69-ebd0-47c7-9309-a6f55db933bf	12ab8d5f-196b-4a2b-91a9-141155386d5e	00000000-0000-0000-0000-000000000001	centraladmin@central.local	ce0295a3c11ac2f25b601ec6d4bcb0b9b3386953c3596caa07ce6c4b4f9bbddc	2026-03-31 19:07:22.771855+00	f	\N	2026-03-30 19:07:22.772354+00
\.


--
-- Data for Name: group_members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.group_members (id, group_id, user_id, tenant_id, added_by, added_at) FROM stdin;
\.


--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.groups (id, tenant_id, name, slug, description, group_type, is_public, auto_role_ids, settings, created_by, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: login_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.login_history (id, user_id, tenant_id, success, failure_reason, session_id, auth_method, mfa_used, device_id, device_type, device_name, ip_address, ip_country, ip_city, user_agent, risk_score, is_suspicious, created_at) FROM stdin;
\.


--
-- Data for Name: oauth_linked_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_linked_accounts (id, user_id, provider_id, provider_user_id, provider_email, provider_name, provider_avatar_url, access_token_encrypted, refresh_token_encrypted, token_expires_at, last_used_at, login_count, linked_at, unlinked_at, is_active) FROM stdin;
\.


--
-- Data for Name: oauth_provider_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_provider_templates (id, provider_type, display_name, authorization_url, token_url, userinfo_url, jwks_url, default_scopes, default_claim_mappings, setup_instructions, documentation_url, icon_url, button_color, is_active) FROM stdin;
8eecc26f-dabf-48d9-99cc-878aa46b18c2	google	Google	https://accounts.google.com/o/oauth2/v2/auth	https://oauth2.googleapis.com/token	https://openidconnect.googleapis.com/v1/userinfo	\N	{openid,profile,email}	{"sub": "provider_user_id", "name": "name", "email": "email", "picture": "avatar_url"}	\N	\N	https://www.google.com/favicon.ico	#4285F4	t
0fcda7cd-9cea-401f-a97d-c89effeafbbe	microsoft	Microsoft	https://login.microsoftonline.com/common/oauth2/v2.0/authorize	https://login.microsoftonline.com/common/oauth2/v2.0/token	https://graph.microsoft.com/oidc/userinfo	\N	{openid,profile,email}	{"sub": "provider_user_id", "name": "name", "email": "email"}	\N	\N	https://www.microsoft.com/favicon.ico	#00A4EF	t
a74cda2f-bea0-41f3-89aa-1882fdbe043d	github	GitHub	https://github.com/login/oauth/authorize	https://github.com/login/oauth/access_token	https://api.github.com/user	\N	{read:user,user:email}	{"id": "provider_user_id", "name": "name", "email": "email", "avatar_url": "avatar_url"}	\N	\N	https://github.com/favicon.ico	#333333	t
\.


--
-- Data for Name: oauth_providers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_providers (id, tenant_id, provider_type, name, display_name, client_id, client_secret_encrypted, authorization_url, token_url, userinfo_url, jwks_url, scopes, claim_mappings, is_enabled, allow_signup, auto_link_by_email, require_email_verified, icon_url, button_color, created_at, updated_at, created_by, metadata) FROM stdin;
\.


--
-- Data for Name: oauth_states; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_states (id, state_token, nonce, provider_id, redirect_uri, code_verifier, client_ip, user_agent, created_at, expires_at, used_at) FROM stdin;
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.password_reset_tokens (id, user_id, tenant_id, token_hash, expires_at, is_used, used_at, used_ip, requested_ip, requested_user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permissions (id, code, name, description, category, is_system, created_at, updated_at) FROM stdin;
20777a54-ea68-4355-a643-c024592eee2c	users:read	View Users	View user profiles and list users	users	t	2026-03-30 09:18:32.76747+00	2026-03-30 09:18:32.76747+00
4f853ee2-0285-49a2-a3ee-4ab12fba1b92	users:write	Manage Users	Create, update, and delete users	users	t	2026-03-30 09:18:32.76747+00	2026-03-30 09:18:32.76747+00
b85b78da-b286-4324-aee3-370050ebb072	users:invite	Invite Users	Invite new users to the tenant	users	t	2026-03-30 09:18:32.76747+00	2026-03-30 09:18:32.76747+00
89c01ce8-1ae2-484b-b4a2-f33bb3be9f09	roles:read	View Roles	View roles and their permissions	roles	t	2026-03-30 09:18:32.76747+00	2026-03-30 09:18:32.76747+00
a26a8919-c9ed-4348-a15a-c99a29d15de3	roles:write	Manage Roles	Create, update, and delete custom roles	roles	t	2026-03-30 09:18:32.76747+00	2026-03-30 09:18:32.76747+00
1a3d4830-45cb-49f0-bf03-f8ada10e88d9	roles:assign	Assign Roles	Assign roles to users	roles	t	2026-03-30 09:18:32.76747+00	2026-03-30 09:18:32.76747+00
4b6aa4b4-1991-4352-b199-043cbc1f1bc9	tenant:read	View Tenant Settings	View tenant configuration	tenant	t	2026-03-30 09:18:32.76747+00	2026-03-30 09:18:32.76747+00
954092c6-7bbd-4486-a04c-846bc6610f45	tenant:write	Manage Tenant Settings	Update tenant configuration	tenant	t	2026-03-30 09:18:32.76747+00	2026-03-30 09:18:32.76747+00
2fd5a60a-f701-454f-8bcb-a6960c104b61	tenant:billing	Manage Billing	Access billing and subscription	tenant	t	2026-03-30 09:18:32.76747+00	2026-03-30 09:18:32.76747+00
b8a46d56-64f8-479b-94b5-581dd6ee1214	sso:read	View SSO Settings	View SSO configuration	sso	t	2026-03-30 09:18:32.76747+00	2026-03-30 09:18:32.76747+00
a5bd70cd-d4dc-43f3-89be-f4d7e59a3822	sso:write	Manage SSO	Configure SSO providers	sso	t	2026-03-30 09:18:32.76747+00	2026-03-30 09:18:32.76747+00
dff32b92-5fee-4b2b-8fad-fdc6e5a9ea46	api:read	Read API Access	Access read-only API endpoints	api	t	2026-03-30 09:18:32.76747+00	2026-03-30 09:18:32.76747+00
9c1670a0-3933-46db-b02d-010865e779a5	api:write	Write API Access	Access write API endpoints	api	t	2026-03-30 09:18:32.76747+00	2026-03-30 09:18:32.76747+00
01441296-91c9-45ec-8006-385015827b03	api:admin	Admin API Access	Access admin API endpoints	api	t	2026-03-30 09:18:32.76747+00	2026-03-30 09:18:32.76747+00
f8b8485f-01d8-46d0-bcbd-0cde745b78d9	audit:read	View Audit Logs	View audit and security logs	audit	t	2026-03-30 09:18:32.76747+00	2026-03-30 09:18:32.76747+00
2532476b-ef49-4b73-8d1c-4dc663dcf4a8	audit:export	Export Audit Logs	Export audit logs for compliance	audit	t	2026-03-30 09:18:32.76747+00	2026-03-30 09:18:32.76747+00
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.refresh_tokens (id, session_id, user_id, tenant_id, token_hash, token_family, is_revoked, expires_at, previous_token_id, rotation_count, created_at, used_at, revoked_at, revoked_reason) FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_permissions (id, role_id, permission_id, conditions, created_at) FROM stdin;
42ec5099-0027-4f28-95d9-10dfee6b892b	00000000-0000-0000-0000-000000000001	20777a54-ea68-4355-a643-c024592eee2c	\N	2026-03-30 09:18:32.776184+00
8ca4f046-9d99-41f1-9efa-af1eed901e3c	00000000-0000-0000-0000-000000000001	4f853ee2-0285-49a2-a3ee-4ab12fba1b92	\N	2026-03-30 09:18:32.776184+00
94db7fc1-9acf-4c3e-95b2-f0b10747a33c	00000000-0000-0000-0000-000000000001	b85b78da-b286-4324-aee3-370050ebb072	\N	2026-03-30 09:18:32.776184+00
8ee8638d-b60c-4432-a848-16eb867b143f	00000000-0000-0000-0000-000000000001	89c01ce8-1ae2-484b-b4a2-f33bb3be9f09	\N	2026-03-30 09:18:32.776184+00
d90be6b9-9125-446a-9c41-ccfda09bfa18	00000000-0000-0000-0000-000000000001	a26a8919-c9ed-4348-a15a-c99a29d15de3	\N	2026-03-30 09:18:32.776184+00
13411cb0-b81e-473e-bde1-8b6d58da42f6	00000000-0000-0000-0000-000000000001	1a3d4830-45cb-49f0-bf03-f8ada10e88d9	\N	2026-03-30 09:18:32.776184+00
c95a4abb-3f78-4be2-a8a6-44e98ce654da	00000000-0000-0000-0000-000000000001	4b6aa4b4-1991-4352-b199-043cbc1f1bc9	\N	2026-03-30 09:18:32.776184+00
48659a67-417d-490a-9505-38bcb22e0ae1	00000000-0000-0000-0000-000000000001	954092c6-7bbd-4486-a04c-846bc6610f45	\N	2026-03-30 09:18:32.776184+00
4c3ee210-d7dc-4c6e-a1e6-c9a343e222db	00000000-0000-0000-0000-000000000001	2fd5a60a-f701-454f-8bcb-a6960c104b61	\N	2026-03-30 09:18:32.776184+00
08cd2c54-2950-4fad-bd13-ade870e8ce6b	00000000-0000-0000-0000-000000000001	b8a46d56-64f8-479b-94b5-581dd6ee1214	\N	2026-03-30 09:18:32.776184+00
798d45e8-b6ae-4235-b2c7-8b2a592e933c	00000000-0000-0000-0000-000000000001	a5bd70cd-d4dc-43f3-89be-f4d7e59a3822	\N	2026-03-30 09:18:32.776184+00
d995986c-8214-4166-8bb7-1b78e48d067a	00000000-0000-0000-0000-000000000001	dff32b92-5fee-4b2b-8fad-fdc6e5a9ea46	\N	2026-03-30 09:18:32.776184+00
e370ab56-8834-4c5a-8c45-d67fde0b4212	00000000-0000-0000-0000-000000000001	9c1670a0-3933-46db-b02d-010865e779a5	\N	2026-03-30 09:18:32.776184+00
50598e6d-4838-47a3-806c-0b3d3eda19b6	00000000-0000-0000-0000-000000000001	01441296-91c9-45ec-8006-385015827b03	\N	2026-03-30 09:18:32.776184+00
12e933c2-6692-4908-bfe7-839660490f80	00000000-0000-0000-0000-000000000001	f8b8485f-01d8-46d0-bcbd-0cde745b78d9	\N	2026-03-30 09:18:32.776184+00
9a6f1819-2319-4416-8bf2-3ae79105798b	00000000-0000-0000-0000-000000000001	2532476b-ef49-4b73-8d1c-4dc663dcf4a8	\N	2026-03-30 09:18:32.776184+00
220e0d83-003d-49b1-8d04-1cad8ba535c0	00000000-0000-0000-0000-000000000002	20777a54-ea68-4355-a643-c024592eee2c	\N	2026-03-30 09:18:32.777844+00
e58a6a91-41b1-418f-96d3-8ac94725b96a	00000000-0000-0000-0000-000000000002	4f853ee2-0285-49a2-a3ee-4ab12fba1b92	\N	2026-03-30 09:18:32.777844+00
b8930c0a-1629-4f10-82ef-63cd6a5586b3	00000000-0000-0000-0000-000000000002	b85b78da-b286-4324-aee3-370050ebb072	\N	2026-03-30 09:18:32.777844+00
4b36c366-29d7-4741-9d51-17cc69d88c3f	00000000-0000-0000-0000-000000000002	89c01ce8-1ae2-484b-b4a2-f33bb3be9f09	\N	2026-03-30 09:18:32.777844+00
9e6242d2-8e76-408e-8e53-38b0927df3e6	00000000-0000-0000-0000-000000000002	a26a8919-c9ed-4348-a15a-c99a29d15de3	\N	2026-03-30 09:18:32.777844+00
9ef1cf2e-d76b-4f66-9c9e-e527f3b81369	00000000-0000-0000-0000-000000000002	1a3d4830-45cb-49f0-bf03-f8ada10e88d9	\N	2026-03-30 09:18:32.777844+00
1590b33f-f3d4-42fb-b0b5-8f1dad90930a	00000000-0000-0000-0000-000000000002	4b6aa4b4-1991-4352-b199-043cbc1f1bc9	\N	2026-03-30 09:18:32.777844+00
bf3c7681-376a-4bba-9102-34036e3d7386	00000000-0000-0000-0000-000000000002	954092c6-7bbd-4486-a04c-846bc6610f45	\N	2026-03-30 09:18:32.777844+00
cdc2a1e8-4421-4ccb-bde1-098a42352db3	00000000-0000-0000-0000-000000000002	2fd5a60a-f701-454f-8bcb-a6960c104b61	\N	2026-03-30 09:18:32.777844+00
80fced74-0b87-48c2-adc6-a70d6b64ac83	00000000-0000-0000-0000-000000000002	b8a46d56-64f8-479b-94b5-581dd6ee1214	\N	2026-03-30 09:18:32.777844+00
5c3a2710-f718-49cf-bcd9-fdffbe538f89	00000000-0000-0000-0000-000000000002	a5bd70cd-d4dc-43f3-89be-f4d7e59a3822	\N	2026-03-30 09:18:32.777844+00
49e52113-0938-4ddb-997a-1ea462920d0e	00000000-0000-0000-0000-000000000002	dff32b92-5fee-4b2b-8fad-fdc6e5a9ea46	\N	2026-03-30 09:18:32.777844+00
e44db505-80cf-41b1-8819-45a4d211496f	00000000-0000-0000-0000-000000000002	9c1670a0-3933-46db-b02d-010865e779a5	\N	2026-03-30 09:18:32.777844+00
fd75a794-eca3-419f-95fe-d6d7bee27cd9	00000000-0000-0000-0000-000000000002	01441296-91c9-45ec-8006-385015827b03	\N	2026-03-30 09:18:32.777844+00
029d15fb-e98f-421d-b3d0-a837536c52fe	00000000-0000-0000-0000-000000000002	f8b8485f-01d8-46d0-bcbd-0cde745b78d9	\N	2026-03-30 09:18:32.777844+00
b17f86a2-9d4f-40dc-ac2a-89f853fc8c3f	00000000-0000-0000-0000-000000000002	2532476b-ef49-4b73-8d1c-4dc663dcf4a8	\N	2026-03-30 09:18:32.777844+00
6551c939-6684-48a6-b382-44827d0b8d18	00000000-0000-0000-0000-000000000003	20777a54-ea68-4355-a643-c024592eee2c	\N	2026-03-30 09:18:32.778765+00
c8c4e2d9-b101-4ba8-aaf6-3324b5810529	00000000-0000-0000-0000-000000000003	4f853ee2-0285-49a2-a3ee-4ab12fba1b92	\N	2026-03-30 09:18:32.778765+00
6fd6f4b4-41bf-45d5-9a0b-e7bcfd7de016	00000000-0000-0000-0000-000000000003	b85b78da-b286-4324-aee3-370050ebb072	\N	2026-03-30 09:18:32.778765+00
1cffcea5-c712-41ed-9802-aafecbd8d199	00000000-0000-0000-0000-000000000003	89c01ce8-1ae2-484b-b4a2-f33bb3be9f09	\N	2026-03-30 09:18:32.778765+00
5d0647a9-5aa2-4966-9ff0-26bf093a7c21	00000000-0000-0000-0000-000000000003	a26a8919-c9ed-4348-a15a-c99a29d15de3	\N	2026-03-30 09:18:32.778765+00
2085006c-eab0-4eba-9c26-f6a6fc74b0cf	00000000-0000-0000-0000-000000000003	1a3d4830-45cb-49f0-bf03-f8ada10e88d9	\N	2026-03-30 09:18:32.778765+00
8903b104-416f-4e19-a0ec-a138e386e628	00000000-0000-0000-0000-000000000003	f8b8485f-01d8-46d0-bcbd-0cde745b78d9	\N	2026-03-30 09:18:32.778765+00
9728f54b-c1b1-4f39-9bd4-4b5163062573	00000000-0000-0000-0000-000000000004	20777a54-ea68-4355-a643-c024592eee2c	\N	2026-03-30 09:18:32.78016+00
e4a4fdce-78b2-4863-80b9-31e1a0205db8	00000000-0000-0000-0000-000000000004	dff32b92-5fee-4b2b-8fad-fdc6e5a9ea46	\N	2026-03-30 09:18:32.78016+00
99128195-b612-434e-8ba7-d9b80d25f228	00000000-0000-0000-0000-000000000005	dff32b92-5fee-4b2b-8fad-fdc6e5a9ea46	\N	2026-03-30 09:18:32.780724+00
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, tenant_id, code, name, description, priority, is_system, is_default, created_at, updated_at) FROM stdin;
00000000-0000-0000-0000-000000000001	\N	super_admin	Super Administrator	Full system access across all tenants. Platform administrators only.	1000	t	f	2026-03-30 09:18:32.772268+00	2026-03-30 09:18:32.772268+00
00000000-0000-0000-0000-000000000002	\N	tenant_admin	Tenant Administrator	Full access within the tenant. Can manage all users and settings.	100	t	f	2026-03-30 09:18:32.772268+00	2026-03-30 09:18:32.772268+00
00000000-0000-0000-0000-000000000003	\N	admin	Administrator	Administrative access. Can manage users but not tenant settings.	50	t	f	2026-03-30 09:18:32.772268+00	2026-03-30 09:18:32.772268+00
00000000-0000-0000-0000-000000000004	\N	member	Member	Standard user access. Can view and edit own profile.	10	t	t	2026-03-30 09:18:32.772268+00	2026-03-30 09:18:32.772268+00
00000000-0000-0000-0000-000000000005	\N	guest	Guest	Limited read-only access. Cannot modify any data.	1	t	f	2026-03-30 09:18:32.772268+00	2026-03-30 09:18:32.772268+00
\.


--
-- Data for Name: security_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.security_events (id, event_type, severity, tenant_id, user_id, description, event_data, detection_method, confidence_score, auto_action_taken, requires_review, reviewed_at, reviewed_by, review_notes, ip_address, ip_country, detected_at, resolved_at) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sessions (id, user_id, tenant_id, session_token_hash, status, device_id, device_name, device_type, device_fingerprint, user_agent, client_version, ip_address, ip_country, ip_city, last_activity_at, expires_at, mfa_verified, mfa_verified_at, risk_score, is_suspicious, created_at, revoked_at, revoked_by, revoked_reason) FROM stdin;
\.


--
-- Data for Name: team_members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.team_members (id, team_id, user_id, tenant_id, role, invited_by, joined_at) FROM stdin;
\.


--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.teams (id, tenant_id, name, slug, description, parent_team_id, is_public, settings, created_by, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tenants (id, name, slug, domain, tier, status, settings, feature_flags, rate_limits, billing_email, stripe_customer_id, subscription_expires_at, sso_enabled, sso_config, data_region, metadata, created_at, updated_at, activated_at, suspended_at, deleted_at, is_deleted) FROM stdin;
00000000-0000-0000-0000-000000000001	Default	default	\N	free	active	{"max_failed_logins": 10, "allow_self_registration": true, "lockout_duration_minutes": 30, "require_email_verification": true}	{"mfa_enabled": true, "sso_enabled": false, "api_keys_enabled": true}	{"max_users": 100, "storage_gb": 5, "api_requests_per_hour": 1000, "max_sessions_per_user": 5}	\N	\N	\N	f	\N	us-east-1	{}	2026-03-30 09:18:36.49723+00	2026-03-30 09:18:36.49723+00	2026-03-30 09:18:36.49723+00	\N	\N	f
\.


--
-- Data for Name: trusted_devices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trusted_devices (id, user_id, tenant_id, device_fingerprint, device_name, device_type, browser, os, ip_address, location_country, location_city, trust_expires_at, trust_level, last_used_at, usage_count, is_revoked, created_at, revoked_at, revoked_reason) FROM stdin;
\.


--
-- Data for Name: user_invitations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_invitations (id, tenant_id, email, token_hash, role_ids, invited_by, message, expires_at, accepted_at, accepted_by, revoked_at, created_at) FROM stdin;
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_roles (id, user_id, role_id, assigned_by, expires_at, scope, created_at) FROM stdin;
4e9c7b02-8d8c-4e90-b752-74308d2cc796	00000000-0000-0000-0000-000000000002	00000000-0000-0000-0000-000000000001	\N	\N	\N	2026-03-30 09:18:38.605108+00
1dd46b64-61da-4c37-9d40-98413666546f	12ab8d5f-196b-4a2b-91a9-141155386d5e	00000000-0000-0000-0000-000000000004	\N	\N	\N	2026-03-30 19:07:22.766752+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, tenant_id, email, email_verified, email_verified_at, password_hash, password_changed_at, password_expires_at, first_name_encrypted, last_name_encrypted, phone_encrypted, display_name, avatar_url, locale, timezone, status, mfa_enabled, mfa_method, mfa_secret_encrypted, mfa_backup_codes_encrypted, mfa_recovery_email, oauth_provider, oauth_provider_id, oauth_access_token_encrypted, oauth_refresh_token_encrypted, oauth_token_expires_at, failed_login_attempts, locked_until, last_login_at, last_login_ip, last_password_reset_at, trusted_devices, risk_score, risk_factors, terms_accepted_at, terms_version, privacy_accepted_at, privacy_version, metadata, created_at, updated_at, deactivated_at, deleted_at, is_deleted) FROM stdin;
00000000-0000-0000-0000-000000000002	00000000-0000-0000-0000-000000000001	admin@central.local	t	2026-03-30 09:18:38.602405+00	$argon2id$v=19$m=19456,t=2,p=1$c2VlZC1zYWx0LWNlbnRyYWw$placeholder-rehash-on-first-login	\N	\N	\N	\N	\N	Central Admin	\N	en-US	UTC	active	f	none	\N	\N	\N	local	\N	\N	\N	\N	0	\N	\N	\N	\N	[]	0.00	{}	\N	\N	\N	\N	{"source": "central_seed", "requires_password_change": true}	2026-03-30 09:18:38.602405+00	2026-03-30 09:18:38.602405+00	\N	\N	f
12ab8d5f-196b-4a2b-91a9-141155386d5e	00000000-0000-0000-0000-000000000001	centraladmin@central.local	t	2026-03-30 19:07:38.034724+00	$argon2id$v=19$m=19456,t=2,p=1$CcnEgWcd7fVcD7HjsBFEYQ$9cb0ac7JCgqdgwXUEsz4cnb0+RUpIIssV5og82NfnCk	\N	\N	\\x24b8cf01a3874e50a496747f0211adc190885d3ab457ff5b6d7cc8bf381d592cee1c69	\\xc6a215fe6d990f8e623a5e60c2a600955a1dd7ee011aed5e839f56fba1c60dd1b6	\N	Central Admin	\N	en-US	UTC	active	f	none	\N	\N	\N	local	\N	\N	\N	\N	0	\N	2026-04-15 09:12:46.624807+00	\N	\N	[]	0.00	{}	2026-03-30 19:07:22.754726+00	1.0	2026-03-30 19:07:22.754726+00	1.0	{}	2026-03-30 19:07:22.754728+00	2026-04-15 09:12:46.624807+00	\N	\N	f
\.


--
-- Data for Name: webauthn_credentials; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webauthn_credentials (id, user_id, tenant_id, credential_id, public_key, name, aaguid, sign_count, transports, attestation_type, attestation_trust_path, last_used_at, usage_count, is_revoked, created_at, revoked_at) FROM stdin;
\.


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 1, false);


--
-- Name: login_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.login_history_id_seq', 1, false);


--
-- Name: security_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.security_events_id_seq', 1, false);


--
-- Name: api_key_usage_log api_key_usage_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_key_usage_log
    ADD CONSTRAINT api_key_usage_log_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_key_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_key_hash_key UNIQUE (key_hash);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_external_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_external_id_key UNIQUE (external_id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: email_verification_tokens email_verification_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_pkey PRIMARY KEY (id);


--
-- Name: email_verification_tokens email_verification_tokens_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_token_hash_key UNIQUE (token_hash);


--
-- Name: group_members group_members_group_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT group_members_group_id_user_id_key UNIQUE (group_id, user_id);


--
-- Name: group_members group_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT group_members_pkey PRIMARY KEY (id);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: groups groups_tenant_id_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_tenant_id_slug_key UNIQUE (tenant_id, slug);


--
-- Name: login_history login_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.login_history
    ADD CONSTRAINT login_history_pkey PRIMARY KEY (id);


--
-- Name: oauth_linked_accounts oauth_linked_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_linked_accounts
    ADD CONSTRAINT oauth_linked_accounts_pkey PRIMARY KEY (id);


--
-- Name: oauth_linked_accounts oauth_linked_accounts_provider_id_provider_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_linked_accounts
    ADD CONSTRAINT oauth_linked_accounts_provider_id_provider_user_id_key UNIQUE (provider_id, provider_user_id);


--
-- Name: oauth_linked_accounts oauth_linked_accounts_user_id_provider_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_linked_accounts
    ADD CONSTRAINT oauth_linked_accounts_user_id_provider_id_key UNIQUE (user_id, provider_id);


--
-- Name: oauth_provider_templates oauth_provider_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_provider_templates
    ADD CONSTRAINT oauth_provider_templates_pkey PRIMARY KEY (id);


--
-- Name: oauth_provider_templates oauth_provider_templates_provider_type_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_provider_templates
    ADD CONSTRAINT oauth_provider_templates_provider_type_key UNIQUE (provider_type);


--
-- Name: oauth_providers oauth_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_providers
    ADD CONSTRAINT oauth_providers_pkey PRIMARY KEY (id);


--
-- Name: oauth_providers oauth_providers_tenant_id_provider_type_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_providers
    ADD CONSTRAINT oauth_providers_tenant_id_provider_type_name_key UNIQUE (tenant_id, provider_type, name);


--
-- Name: oauth_states oauth_states_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_states
    ADD CONSTRAINT oauth_states_pkey PRIMARY KEY (id);


--
-- Name: oauth_states oauth_states_state_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_states
    ADD CONSTRAINT oauth_states_state_token_key UNIQUE (state_token);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_token_hash_key UNIQUE (token_hash);


--
-- Name: permissions permissions_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_code_key UNIQUE (code);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_hash_key UNIQUE (token_hash);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: security_events security_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.security_events
    ADD CONSTRAINT security_events_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_session_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_session_token_hash_key UNIQUE (session_token_hash);


--
-- Name: team_members team_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_pkey PRIMARY KEY (id);


--
-- Name: team_members team_members_team_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_team_id_user_id_key UNIQUE (team_id, user_id);


--
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (id);


--
-- Name: teams teams_tenant_id_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_tenant_id_slug_key UNIQUE (tenant_id, slug);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_slug_key UNIQUE (slug);


--
-- Name: trusted_devices trusted_devices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trusted_devices
    ADD CONSTRAINT trusted_devices_pkey PRIMARY KEY (id);


--
-- Name: trusted_devices trusted_devices_user_id_device_fingerprint_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trusted_devices
    ADD CONSTRAINT trusted_devices_user_id_device_fingerprint_key UNIQUE (user_id, device_fingerprint);


--
-- Name: users unique_email_per_tenant; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT unique_email_per_tenant UNIQUE (tenant_id, email);


--
-- Name: user_invitations unique_pending_invitation; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_invitations
    ADD CONSTRAINT unique_pending_invitation UNIQUE (tenant_id, email);


--
-- Name: roles unique_role_code_per_tenant; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT unique_role_code_per_tenant UNIQUE (tenant_id, code);


--
-- Name: role_permissions unique_role_permission; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT unique_role_permission UNIQUE (role_id, permission_id);


--
-- Name: user_roles unique_user_role; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT unique_user_role UNIQUE (user_id, role_id);


--
-- Name: user_invitations user_invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_invitations
    ADD CONSTRAINT user_invitations_pkey PRIMARY KEY (id);


--
-- Name: user_invitations user_invitations_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_invitations
    ADD CONSTRAINT user_invitations_token_hash_key UNIQUE (token_hash);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: webauthn_credentials webauthn_credentials_credential_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_credential_id_key UNIQUE (credential_id);


--
-- Name: webauthn_credentials webauthn_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_pkey PRIMARY KEY (id);


--
-- Name: idx_api_key_usage_log_key_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_api_key_usage_log_key_id ON public.api_key_usage_log USING btree (api_key_id, created_at DESC);


--
-- Name: idx_api_keys_key_prefix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_api_keys_key_prefix ON public.api_keys USING btree (key_prefix);


--
-- Name: idx_api_keys_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_api_keys_lookup ON public.api_keys USING btree (key_hash, is_revoked, expires_at) WHERE (NOT is_revoked);


--
-- Name: idx_api_keys_prefix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_api_keys_prefix ON public.api_keys USING btree (key_prefix);


--
-- Name: idx_api_keys_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_api_keys_tenant ON public.api_keys USING btree (tenant_id) WHERE (NOT is_revoked);


--
-- Name: idx_api_keys_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_api_keys_user ON public.api_keys USING btree (user_id) WHERE (NOT is_revoked);


--
-- Name: idx_audit_logs_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_action ON public.audit_logs USING btree (action, created_at DESC);


--
-- Name: idx_audit_logs_actor_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_actor_id ON public.audit_logs USING btree (actor_id, created_at DESC);


--
-- Name: idx_audit_logs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_created_at ON public.audit_logs USING btree (created_at DESC);


--
-- Name: idx_audit_logs_created_brin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_created_brin ON public.audit_logs USING brin (created_at) WITH (pages_per_range='128');


--
-- Name: idx_audit_logs_event_data; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_event_data ON public.audit_logs USING gin (event_data);


--
-- Name: idx_audit_logs_ip; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_ip ON public.audit_logs USING btree (ip_address, created_at DESC);


--
-- Name: idx_audit_logs_request_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_request_id ON public.audit_logs USING btree (request_id);


--
-- Name: idx_audit_logs_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_session_id ON public.audit_logs USING btree (session_id, created_at DESC);


--
-- Name: idx_audit_logs_success; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_success ON public.audit_logs USING btree (tenant_id, success, created_at DESC) WHERE (NOT success);


--
-- Name: idx_audit_logs_target_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_target_id ON public.audit_logs USING btree (target_id, created_at DESC);


--
-- Name: idx_audit_logs_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_tenant_id ON public.audit_logs USING btree (tenant_id, created_at DESC);


--
-- Name: idx_email_verify_expires; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_email_verify_expires ON public.email_verification_tokens USING btree (expires_at) WHERE (NOT is_used);


--
-- Name: idx_email_verify_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_email_verify_user ON public.email_verification_tokens USING btree (user_id) WHERE (NOT is_used);


--
-- Name: idx_group_members_group; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_group_members_group ON public.group_members USING btree (group_id);


--
-- Name: idx_group_members_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_group_members_tenant ON public.group_members USING btree (tenant_id);


--
-- Name: idx_group_members_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_group_members_user ON public.group_members USING btree (user_id);


--
-- Name: idx_groups_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_groups_slug ON public.groups USING btree (tenant_id, slug) WHERE (deleted_at IS NULL);


--
-- Name: idx_groups_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_groups_tenant ON public.groups USING btree (tenant_id) WHERE (deleted_at IS NULL);


--
-- Name: idx_groups_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_groups_type ON public.groups USING btree (tenant_id, group_type) WHERE (deleted_at IS NULL);


--
-- Name: idx_invitations_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invitations_email ON public.user_invitations USING btree (email) WHERE ((accepted_at IS NULL) AND (revoked_at IS NULL));


--
-- Name: idx_invitations_expires; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invitations_expires ON public.user_invitations USING btree (expires_at) WHERE ((accepted_at IS NULL) AND (revoked_at IS NULL));


--
-- Name: idx_invitations_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invitations_tenant ON public.user_invitations USING btree (tenant_id) WHERE ((accepted_at IS NULL) AND (revoked_at IS NULL));


--
-- Name: idx_invitations_token; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invitations_token ON public.user_invitations USING btree (token_hash) WHERE ((accepted_at IS NULL) AND (revoked_at IS NULL));


--
-- Name: idx_login_history_created_brin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_login_history_created_brin ON public.login_history USING brin (created_at) WITH (pages_per_range='128');


--
-- Name: idx_login_history_failures; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_login_history_failures ON public.login_history USING btree (user_id, created_at DESC) WHERE (NOT success);


--
-- Name: idx_login_history_ip; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_login_history_ip ON public.login_history USING btree (ip_address, created_at DESC);


--
-- Name: idx_login_history_suspicious; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_login_history_suspicious ON public.login_history USING btree (tenant_id, created_at DESC) WHERE is_suspicious;


--
-- Name: idx_login_history_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_login_history_tenant ON public.login_history USING btree (tenant_id, created_at DESC);


--
-- Name: idx_login_history_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_login_history_user ON public.login_history USING btree (user_id, created_at DESC);


--
-- Name: idx_mv_tenant_security_stats; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_mv_tenant_security_stats ON public.mv_tenant_security_stats USING btree (tenant_id);


--
-- Name: idx_mv_tenant_session_stats; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_mv_tenant_session_stats ON public.mv_tenant_session_stats USING btree (tenant_id);


--
-- Name: idx_mv_tenant_user_stats; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_mv_tenant_user_stats ON public.mv_tenant_user_stats USING btree (tenant_id);


--
-- Name: idx_oauth_linked_accounts_provider_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_oauth_linked_accounts_provider_user ON public.oauth_linked_accounts USING btree (provider_id, provider_user_id) WHERE is_active;


--
-- Name: idx_oauth_linked_accounts_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_oauth_linked_accounts_user_id ON public.oauth_linked_accounts USING btree (user_id) WHERE is_active;


--
-- Name: idx_oauth_providers_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_oauth_providers_tenant_id ON public.oauth_providers USING btree (tenant_id) WHERE is_enabled;


--
-- Name: idx_oauth_states_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_oauth_states_expires_at ON public.oauth_states USING btree (expires_at) WHERE (used_at IS NULL);


--
-- Name: idx_password_reset_expires; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_password_reset_expires ON public.password_reset_tokens USING btree (expires_at) WHERE (NOT is_used);


--
-- Name: idx_password_reset_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_password_reset_user ON public.password_reset_tokens USING btree (user_id) WHERE (NOT is_used);


--
-- Name: idx_permissions_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_permissions_category ON public.permissions USING btree (category);


--
-- Name: idx_refresh_tokens_expires; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_refresh_tokens_expires ON public.refresh_tokens USING btree (expires_at) WHERE (NOT is_revoked);


--
-- Name: idx_refresh_tokens_family; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_refresh_tokens_family ON public.refresh_tokens USING btree (token_family);


--
-- Name: idx_refresh_tokens_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_refresh_tokens_lookup ON public.refresh_tokens USING btree (token_hash, is_revoked, expires_at) WHERE (NOT is_revoked);


--
-- Name: idx_refresh_tokens_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_refresh_tokens_session ON public.refresh_tokens USING btree (session_id) WHERE (NOT is_revoked);


--
-- Name: idx_refresh_tokens_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_refresh_tokens_user ON public.refresh_tokens USING btree (user_id) WHERE (NOT is_revoked);


--
-- Name: idx_role_permissions_permission; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_role_permissions_permission ON public.role_permissions USING btree (permission_id);


--
-- Name: idx_role_permissions_role; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_role_permissions_role ON public.role_permissions USING btree (role_id);


--
-- Name: idx_roles_is_default; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_roles_is_default ON public.roles USING btree (tenant_id, is_default) WHERE (is_default = true);


--
-- Name: idx_roles_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_roles_tenant_id ON public.roles USING btree (tenant_id) WHERE (tenant_id IS NOT NULL);


--
-- Name: idx_security_events_detected_brin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_security_events_detected_brin ON public.security_events USING brin (detected_at) WITH (pages_per_range='128');


--
-- Name: idx_security_events_severity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_security_events_severity ON public.security_events USING btree (severity, detected_at DESC) WHERE ((severity)::text = ANY ((ARRAY['high'::character varying, 'critical'::character varying])::text[]));


--
-- Name: idx_security_events_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_security_events_tenant ON public.security_events USING btree (tenant_id, detected_at DESC);


--
-- Name: idx_security_events_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_security_events_type ON public.security_events USING btree (event_type, detected_at DESC);


--
-- Name: idx_security_events_unreviewed; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_security_events_unreviewed ON public.security_events USING btree (requires_review, detected_at DESC) WHERE (requires_review AND (reviewed_at IS NULL));


--
-- Name: idx_security_events_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_security_events_user ON public.security_events USING btree (user_id, detected_at DESC);


--
-- Name: idx_sessions_device; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sessions_device ON public.sessions USING btree (user_id, device_id);


--
-- Name: idx_sessions_expires; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sessions_expires ON public.sessions USING btree (expires_at) WHERE (status = 'active'::public.session_status);


--
-- Name: idx_sessions_suspicious; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sessions_suspicious ON public.sessions USING btree (tenant_id, is_suspicious) WHERE (is_suspicious = true);


--
-- Name: idx_sessions_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sessions_tenant_id ON public.sessions USING btree (tenant_id) WHERE (status = 'active'::public.session_status);


--
-- Name: idx_sessions_token_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sessions_token_hash ON public.sessions USING btree (session_token_hash);


--
-- Name: idx_sessions_user_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sessions_user_active ON public.sessions USING btree (user_id, last_activity_at DESC) WHERE (status = 'active'::public.session_status);


--
-- Name: idx_sessions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sessions_user_id ON public.sessions USING btree (user_id) WHERE (status = 'active'::public.session_status);


--
-- Name: idx_sessions_validate; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sessions_validate ON public.sessions USING btree (session_token_hash, status, expires_at) WHERE (status = 'active'::public.session_status);


--
-- Name: idx_team_members_team; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_team_members_team ON public.team_members USING btree (team_id);


--
-- Name: idx_team_members_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_team_members_tenant ON public.team_members USING btree (tenant_id);


--
-- Name: idx_team_members_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_team_members_user ON public.team_members USING btree (user_id);


--
-- Name: idx_teams_parent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_teams_parent ON public.teams USING btree (parent_team_id) WHERE ((parent_team_id IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: idx_teams_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_teams_slug ON public.teams USING btree (tenant_id, slug) WHERE (deleted_at IS NULL);


--
-- Name: idx_teams_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_teams_tenant ON public.teams USING btree (tenant_id) WHERE (deleted_at IS NULL);


--
-- Name: idx_tenants_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tenants_created_at ON public.tenants USING btree (created_at DESC);


--
-- Name: idx_tenants_domain; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tenants_domain ON public.tenants USING btree (domain) WHERE ((domain IS NOT NULL) AND (NOT is_deleted));


--
-- Name: idx_tenants_feature_flags; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tenants_feature_flags ON public.tenants USING gin (feature_flags);


--
-- Name: idx_tenants_routing; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tenants_routing ON public.tenants USING btree (slug, status) WHERE ((NOT is_deleted) AND (status = 'active'::public.tenant_status));


--
-- Name: idx_tenants_settings; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tenants_settings ON public.tenants USING gin (settings);


--
-- Name: idx_tenants_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tenants_slug ON public.tenants USING btree (slug) WHERE (NOT is_deleted);


--
-- Name: idx_tenants_sso_routing; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tenants_sso_routing ON public.tenants USING btree (domain, sso_enabled) WHERE ((domain IS NOT NULL) AND sso_enabled AND (NOT is_deleted));


--
-- Name: idx_tenants_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tenants_status ON public.tenants USING btree (status) WHERE (NOT is_deleted);


--
-- Name: idx_tenants_tier; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tenants_tier ON public.tenants USING btree (tier) WHERE (NOT is_deleted);


--
-- Name: idx_trusted_devices_fingerprint; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_trusted_devices_fingerprint ON public.trusted_devices USING btree (device_fingerprint) WHERE (NOT is_revoked);


--
-- Name: idx_trusted_devices_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_trusted_devices_tenant_id ON public.trusted_devices USING btree (tenant_id);


--
-- Name: idx_trusted_devices_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_trusted_devices_user_id ON public.trusted_devices USING btree (user_id) WHERE (NOT is_revoked);


--
-- Name: idx_user_roles_expires; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_roles_expires ON public.user_roles USING btree (expires_at) WHERE (expires_at IS NOT NULL);


--
-- Name: idx_user_roles_role; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_roles_role ON public.user_roles USING btree (role_id);


--
-- Name: idx_user_roles_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_roles_user ON public.user_roles USING btree (user_id);


--
-- Name: idx_users_auth_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_auth_lookup ON public.users USING btree (tenant_id, email, status) WHERE (NOT is_deleted);


--
-- Name: idx_users_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_created_at ON public.users USING btree (created_at DESC);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_email ON public.users USING btree (tenant_id, email) WHERE (NOT is_deleted);


--
-- Name: idx_users_last_login; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_last_login ON public.users USING btree (tenant_id, last_login_at DESC) WHERE (NOT is_deleted);


--
-- Name: idx_users_locked; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_locked ON public.users USING btree (locked_until) WHERE (locked_until IS NOT NULL);


--
-- Name: idx_users_mfa_enabled; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_mfa_enabled ON public.users USING btree (tenant_id) WHERE (mfa_enabled AND (NOT is_deleted));


--
-- Name: idx_users_oauth_provider; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_oauth_provider ON public.users USING btree (oauth_provider, oauth_provider_id) WHERE ((oauth_provider <> 'local'::public.oauth_provider) AND (NOT is_deleted));


--
-- Name: idx_users_pending_verification; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_pending_verification ON public.users USING btree (tenant_id, created_at) WHERE ((status = 'pending_verification'::public.user_status) AND (NOT is_deleted));


--
-- Name: idx_users_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_status ON public.users USING btree (tenant_id, status) WHERE (NOT is_deleted);


--
-- Name: idx_users_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_tenant_id ON public.users USING btree (tenant_id) WHERE (NOT is_deleted);


--
-- Name: idx_webauthn_credential; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_webauthn_credential ON public.webauthn_credentials USING btree (credential_id);


--
-- Name: idx_webauthn_credential_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_webauthn_credential_id ON public.webauthn_credentials USING btree (credential_id) WHERE (NOT is_revoked);


--
-- Name: idx_webauthn_tenant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_webauthn_tenant_id ON public.webauthn_credentials USING btree (tenant_id);


--
-- Name: idx_webauthn_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_webauthn_user ON public.webauthn_credentials USING btree (user_id) WHERE (NOT is_revoked);


--
-- Name: idx_webauthn_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_webauthn_user_id ON public.webauthn_credentials USING btree (user_id) WHERE (NOT is_revoked);


--
-- Name: audit_logs protect_audit_logs_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER protect_audit_logs_delete BEFORE DELETE ON public.audit_logs FOR EACH ROW EXECUTE FUNCTION public.prevent_audit_modification();


--
-- Name: audit_logs protect_audit_logs_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER protect_audit_logs_update BEFORE UPDATE ON public.audit_logs FOR EACH ROW EXECUTE FUNCTION public.prevent_audit_modification();


--
-- Name: groups set_groups_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER set_groups_updated_at BEFORE UPDATE ON public.groups FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: teams set_teams_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER set_teams_updated_at BEFORE UPDATE ON public.teams FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: permissions trigger_permissions_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_permissions_updated_at BEFORE UPDATE ON public.permissions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: roles trigger_roles_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_roles_updated_at BEFORE UPDATE ON public.roles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: tenants trigger_tenants_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_tenants_updated_at BEFORE UPDATE ON public.tenants FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users trigger_users_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: api_key_usage_log api_key_usage_log_api_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_key_usage_log
    ADD CONSTRAINT api_key_usage_log_api_key_id_fkey FOREIGN KEY (api_key_id) REFERENCES public.api_keys(id) ON DELETE CASCADE;


--
-- Name: api_keys api_keys_revoked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_revoked_by_fkey FOREIGN KEY (revoked_by) REFERENCES public.users(id);


--
-- Name: api_keys api_keys_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: api_keys api_keys_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: email_verification_tokens email_verification_tokens_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: email_verification_tokens email_verification_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: group_members group_members_added_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT group_members_added_by_fkey FOREIGN KEY (added_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: group_members group_members_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT group_members_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: group_members group_members_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT group_members_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: group_members group_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT group_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: groups groups_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: groups groups_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: login_history login_history_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.login_history
    ADD CONSTRAINT login_history_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.sessions(id);


--
-- Name: login_history login_history_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.login_history
    ADD CONSTRAINT login_history_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: login_history login_history_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.login_history
    ADD CONSTRAINT login_history_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: oauth_linked_accounts oauth_linked_accounts_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_linked_accounts
    ADD CONSTRAINT oauth_linked_accounts_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.oauth_providers(id) ON DELETE CASCADE;


--
-- Name: oauth_linked_accounts oauth_linked_accounts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_linked_accounts
    ADD CONSTRAINT oauth_linked_accounts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: oauth_providers oauth_providers_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_providers
    ADD CONSTRAINT oauth_providers_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: oauth_states oauth_states_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_states
    ADD CONSTRAINT oauth_states_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.oauth_providers(id) ON DELETE CASCADE;


--
-- Name: password_reset_tokens password_reset_tokens_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: password_reset_tokens password_reset_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_previous_token_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_previous_token_id_fkey FOREIGN KEY (previous_token_id) REFERENCES public.refresh_tokens(id);


--
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.sessions(id) ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: roles roles_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: security_events security_events_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.security_events
    ADD CONSTRAINT security_events_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- Name: security_events security_events_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.security_events
    ADD CONSTRAINT security_events_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: security_events security_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.security_events
    ADD CONSTRAINT security_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: sessions sessions_revoked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_revoked_by_fkey FOREIGN KEY (revoked_by) REFERENCES public.users(id);


--
-- Name: sessions sessions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: team_members team_members_invited_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_invited_by_fkey FOREIGN KEY (invited_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: team_members team_members_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id) ON DELETE CASCADE;


--
-- Name: team_members team_members_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: team_members team_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: teams teams_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: teams teams_parent_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_parent_team_id_fkey FOREIGN KEY (parent_team_id) REFERENCES public.teams(id) ON DELETE SET NULL;


--
-- Name: teams teams_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: trusted_devices trusted_devices_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trusted_devices
    ADD CONSTRAINT trusted_devices_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: trusted_devices trusted_devices_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trusted_devices
    ADD CONSTRAINT trusted_devices_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_invitations user_invitations_accepted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_invitations
    ADD CONSTRAINT user_invitations_accepted_by_fkey FOREIGN KEY (accepted_by) REFERENCES public.users(id);


--
-- Name: user_invitations user_invitations_invited_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_invitations
    ADD CONSTRAINT user_invitations_invited_by_fkey FOREIGN KEY (invited_by) REFERENCES public.users(id);


--
-- Name: user_invitations user_invitations_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_invitations
    ADD CONSTRAINT user_invitations_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_assigned_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_assigned_by_fkey FOREIGN KEY (assigned_by) REFERENCES public.users(id);


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: webauthn_credentials webauthn_credentials_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: webauthn_credentials webauthn_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: api_keys; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.api_keys ENABLE ROW LEVEL SECURITY;

--
-- Name: api_keys api_keys_super_admin_policy; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY api_keys_super_admin_policy ON public.api_keys USING (((current_setting('app.is_super_admin'::text, true))::boolean = true));


--
-- Name: api_keys api_keys_tenant_admin_policy; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY api_keys_tenant_admin_policy ON public.api_keys USING (((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid) AND ((current_setting('app.is_admin'::text, true))::boolean = true)));


--
-- Name: api_keys api_keys_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY api_keys_tenant_isolation ON public.api_keys USING ((public.is_super_admin() OR (tenant_id = public.get_current_tenant_id()))) WITH CHECK ((public.is_super_admin() OR (tenant_id = public.get_current_tenant_id())));


--
-- Name: api_keys api_keys_user_policy; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY api_keys_user_policy ON public.api_keys USING ((user_id = (current_setting('app.current_user_id'::text, true))::uuid));


--
-- Name: audit_logs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: audit_logs audit_logs_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY audit_logs_read ON public.audit_logs FOR SELECT USING ((public.is_super_admin() OR (tenant_id = public.get_current_tenant_id())));


--
-- Name: email_verification_tokens; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.email_verification_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: email_verification_tokens email_verify_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY email_verify_tenant_isolation ON public.email_verification_tokens USING ((public.is_super_admin() OR (tenant_id = public.get_current_tenant_id()))) WITH CHECK ((public.is_super_admin() OR (tenant_id = public.get_current_tenant_id())));


--
-- Name: group_members; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.group_members ENABLE ROW LEVEL SECURITY;

--
-- Name: group_members group_members_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY group_members_tenant_isolation ON public.group_members USING ((tenant_id = (current_setting('app.tenant_id'::text, true))::uuid));


--
-- Name: groups; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.groups ENABLE ROW LEVEL SECURITY;

--
-- Name: groups groups_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY groups_tenant_isolation ON public.groups USING ((tenant_id = (current_setting('app.tenant_id'::text, true))::uuid));


--
-- Name: login_history; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.login_history ENABLE ROW LEVEL SECURITY;

--
-- Name: login_history login_history_tenant; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY login_history_tenant ON public.login_history USING ((public.is_super_admin() OR (tenant_id = public.get_current_tenant_id()))) WITH CHECK ((public.is_super_admin() OR (tenant_id = public.get_current_tenant_id())));


--
-- Name: oauth_linked_accounts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.oauth_linked_accounts ENABLE ROW LEVEL SECURITY;

--
-- Name: oauth_linked_accounts oauth_linked_accounts_super_admin_policy; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY oauth_linked_accounts_super_admin_policy ON public.oauth_linked_accounts USING (((current_setting('app.is_super_admin'::text, true))::boolean = true));


--
-- Name: oauth_linked_accounts oauth_linked_accounts_user_policy; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY oauth_linked_accounts_user_policy ON public.oauth_linked_accounts USING ((user_id = (current_setting('app.current_user_id'::text, true))::uuid));


--
-- Name: oauth_providers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.oauth_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: oauth_providers oauth_providers_super_admin_policy; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY oauth_providers_super_admin_policy ON public.oauth_providers USING (((current_setting('app.is_super_admin'::text, true))::boolean = true));


--
-- Name: oauth_providers oauth_providers_tenant_admin_policy; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY oauth_providers_tenant_admin_policy ON public.oauth_providers USING (((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid) AND ((current_setting('app.is_admin'::text, true))::boolean = true)));


--
-- Name: oauth_states; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.oauth_states ENABLE ROW LEVEL SECURITY;

--
-- Name: password_reset_tokens password_reset_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY password_reset_tenant_isolation ON public.password_reset_tokens USING ((public.is_super_admin() OR (tenant_id = public.get_current_tenant_id()))) WITH CHECK ((public.is_super_admin() OR (tenant_id = public.get_current_tenant_id())));


--
-- Name: password_reset_tokens; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.password_reset_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.refresh_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: refresh_tokens refresh_tokens_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY refresh_tokens_tenant_isolation ON public.refresh_tokens USING ((public.is_super_admin() OR (tenant_id = public.get_current_tenant_id()))) WITH CHECK ((public.is_super_admin() OR (tenant_id = public.get_current_tenant_id())));


--
-- Name: roles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.roles ENABLE ROW LEVEL SECURITY;

--
-- Name: roles roles_tenant_delete; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY roles_tenant_delete ON public.roles FOR DELETE USING ((public.is_super_admin() OR ((tenant_id = public.get_current_tenant_id()) AND (NOT is_system))));


--
-- Name: roles roles_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY roles_tenant_isolation ON public.roles FOR SELECT USING ((public.is_super_admin() OR (tenant_id IS NULL) OR (tenant_id = public.get_current_tenant_id())));


--
-- Name: roles roles_tenant_update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY roles_tenant_update ON public.roles FOR UPDATE USING ((public.is_super_admin() OR ((tenant_id = public.get_current_tenant_id()) AND (NOT is_system)))) WITH CHECK ((public.is_super_admin() OR ((tenant_id = public.get_current_tenant_id()) AND (NOT is_system))));


--
-- Name: roles roles_tenant_write; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY roles_tenant_write ON public.roles FOR INSERT WITH CHECK ((public.is_super_admin() OR ((tenant_id = public.get_current_tenant_id()) AND (NOT is_system))));


--
-- Name: security_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.security_events ENABLE ROW LEVEL SECURITY;

--
-- Name: security_events security_events_tenant; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY security_events_tenant ON public.security_events FOR SELECT USING ((public.is_super_admin() OR (tenant_id = public.get_current_tenant_id())));


--
-- Name: sessions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: sessions sessions_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY sessions_tenant_isolation ON public.sessions USING ((public.is_super_admin() OR (tenant_id = public.get_current_tenant_id()))) WITH CHECK ((public.is_super_admin() OR (tenant_id = public.get_current_tenant_id())));


--
-- Name: team_members; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.team_members ENABLE ROW LEVEL SECURITY;

--
-- Name: team_members team_members_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY team_members_tenant_isolation ON public.team_members USING ((tenant_id = (current_setting('app.tenant_id'::text, true))::uuid));


--
-- Name: teams; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.teams ENABLE ROW LEVEL SECURITY;

--
-- Name: teams teams_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY teams_tenant_isolation ON public.teams USING ((tenant_id = (current_setting('app.tenant_id'::text, true))::uuid));


--
-- Name: trusted_devices; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.trusted_devices ENABLE ROW LEVEL SECURITY;

--
-- Name: trusted_devices trusted_devices_super_admin_policy; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY trusted_devices_super_admin_policy ON public.trusted_devices USING (((current_setting('app.is_super_admin'::text, true))::boolean = true));


--
-- Name: trusted_devices trusted_devices_tenant_admin_policy; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY trusted_devices_tenant_admin_policy ON public.trusted_devices FOR SELECT USING (((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid) AND ((current_setting('app.is_admin'::text, true))::boolean = true)));


--
-- Name: trusted_devices trusted_devices_user_policy; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY trusted_devices_user_policy ON public.trusted_devices USING ((user_id = (current_setting('app.current_user_id'::text, true))::uuid));


--
-- Name: user_roles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

--
-- Name: user_roles user_roles_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY user_roles_tenant_isolation ON public.user_roles USING ((public.is_super_admin() OR (EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = user_roles.user_id) AND (u.tenant_id = public.get_current_tenant_id())))))) WITH CHECK ((public.is_super_admin() OR (EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = user_roles.user_id) AND (u.tenant_id = public.get_current_tenant_id()))))));


--
-- Name: users; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

--
-- Name: users users_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY users_tenant_isolation ON public.users USING ((public.is_super_admin() OR (tenant_id = public.get_current_tenant_id()))) WITH CHECK ((public.is_super_admin() OR (tenant_id = public.get_current_tenant_id())));


--
-- Name: webauthn_credentials; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.webauthn_credentials ENABLE ROW LEVEL SECURITY;

--
-- Name: webauthn_credentials webauthn_super_admin_policy; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY webauthn_super_admin_policy ON public.webauthn_credentials USING (((current_setting('app.is_super_admin'::text, true))::boolean = true));


--
-- Name: webauthn_credentials webauthn_tenant_admin_policy; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY webauthn_tenant_admin_policy ON public.webauthn_credentials FOR SELECT USING (((tenant_id = (current_setting('app.current_tenant_id'::text, true))::uuid) AND ((current_setting('app.is_admin'::text, true))::boolean = true)));


--
-- Name: webauthn_credentials webauthn_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY webauthn_tenant_isolation ON public.webauthn_credentials USING ((public.is_super_admin() OR (tenant_id = public.get_current_tenant_id()))) WITH CHECK ((public.is_super_admin() OR (tenant_id = public.get_current_tenant_id())));


--
-- Name: webauthn_credentials webauthn_user_policy; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY webauthn_user_policy ON public.webauthn_credentials USING ((user_id = (current_setting('app.current_user_id'::text, true))::uuid));


--
-- Name: mv_tenant_security_stats; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: -
--

REFRESH MATERIALIZED VIEW public.mv_tenant_security_stats;


--
-- Name: mv_tenant_session_stats; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: -
--

REFRESH MATERIALIZED VIEW public.mv_tenant_session_stats;


--
-- Name: mv_tenant_user_stats; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: -
--

REFRESH MATERIALIZED VIEW public.mv_tenant_user_stats;


--
-- PostgreSQL database dump complete
--

\unrestrict wwVVgyAleo4MOveXJfSlN1QlX7MSsRVRP3CJ4LKTdK9kL5FKhJNe9gBApJGGyEu

